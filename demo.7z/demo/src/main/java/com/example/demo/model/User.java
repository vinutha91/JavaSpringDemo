package com.example.demo.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import com.example.demo.constants.Constants;

public class User {

    @NotEmpty(message = "Please provide an email.")
    @Pattern(regexp = Constants.EMAIL_REGEX,message = "Please provide a valid email.")
    private String email;

    @NotEmpty(message = "Please provide a name.")
    private String username;

    @NotEmpty(message = "Please provide a password.")
    private String password;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

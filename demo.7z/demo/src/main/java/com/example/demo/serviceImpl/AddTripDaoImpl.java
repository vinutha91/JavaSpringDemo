package com.example.demo.serviceImpl;

import com.example.demo.Exceptions.UserVehicleException;
import com.example.demo.model.ApiError;
import com.example.demo.model.TripDetails;
import com.example.demo.model.AddTripEntity;
import com.example.demo.respository.AddTripRepository;
import com.example.demo.respository.UserVehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.Instant;

@Service
public class AddTripDaoImpl {
    @Autowired
    AddTripRepository addTripRepo;


    @Transactional
    public ResponseEntity<Object> saveData(TripDetails tripDetails) throws UserVehicleException {
        AddTripEntity values = new AddTripEntity();
        boolean compareReading = false;
       /* if(tripDetails.lastTripReading > tripDetails.currentKmsReading){

        }*/
       if(Integer.parseInt(tripDetails.lastTripReading) > Integer.parseInt(tripDetails.currentKmsReading)){
           throw new UserVehicleException(new ApiError("400",
                   "Your previous trip reading cannot be greater than the current trip reading."));
       }




        values.setVehicleNo(tripDetails.vehicleNo);
        values.setLastTripReading(tripDetails.lastTripReading);
        if(tripDetails.lastUpdatedDate == null){
           // Instant instant = Instant.now();
           // values.setLastUpdatedDate(instant.toString());
            values.setLastUpdatedDate(Instant.now().toString());
        }
        //values.setLastUpdatedDate(tripDetails.lastUpdatedDate);
        values.setLitresFilled(tripDetails.litresFilled);
        values.setCurrentKmsReading(tripDetails.currentKmsReading);
        values.setFuelPricePerltr(tripDetails.fuelPricePerltr);
        values.setPetrolFilledForAmt(tripDetails.petrolFilledForAmt);

        addTripRepo.save(values);
        //todo - add try catch in controller
        return new ResponseEntity<>("OK", HttpStatus.OK);
    }
}

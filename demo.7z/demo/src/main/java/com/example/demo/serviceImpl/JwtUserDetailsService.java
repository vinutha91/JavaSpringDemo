package com.example.demo.serviceImpl;

import com.example.demo.Exceptions.UserVehicleException;
import com.example.demo.model.ApiError;
import com.example.demo.model.User;
import com.example.demo.model.UserEntity;
import com.example.demo.respository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;

@Service
public class JwtUserDetailsService implements UserDetailsService {


    @Autowired
    private UserRepository userRepo;


    @Autowired
    private PasswordEncoder bcryptEncoder;


    @Override
    public UserDetails loadUserByUsername(String userEmail) throws UsernameNotFoundException {

        UserEntity user  = userRepo.findByEmail(userEmail);

        if(user == null){
            throw new UsernameNotFoundException("User not found with username: " + userEmail);
        }

        return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(),
                new ArrayList<>());
    }

    @Transactional
    public UserEntity save(User user) throws UserVehicleException{
        if(userRepo.existsById(user.getEmail())){
            throw new UserVehicleException(new ApiError("400",
                    "User already exists"));
        }
        UserEntity newUser = new UserEntity();
        newUser.setUsername(user.getUsername());
        newUser.setEmail(user.getEmail());
        newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
        return  userRepo.save(newUser);
    }
}

package com.example.demo.controller;

import com.example.demo.Exceptions.UserVehicleException;
import com.example.demo.model.TripDetails;
import com.example.demo.model.UserVehicleEntity;
import com.example.demo.model.Vehicle;
import com.example.demo.serviceImpl.AddTripDaoImpl;
import com.example.demo.serviceImpl.VehicleDetailsDaoImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "/userVehicle")
public class UserVehicleController {
	@Autowired
	VehicleDetailsDaoImpl vehicleDetails;

	@Autowired
	AddTripDaoImpl addTripDetails;

	@PostMapping("/signup")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<Object> createUser(@Valid @RequestBody Vehicle newVehicle) throws UserVehicleException {
		try{
			return vehicleDetails.saveData(newVehicle);
		}catch (UserVehicleException ex){
			return new ResponseEntity<Object>(ex.getApiError(), HttpStatus.BAD_REQUEST);
		}
	}
	@PutMapping("/update")
	public ResponseEntity<String> updateUser(@Valid @RequestBody Vehicle newVehicle){
		return vehicleDetails.updateData(newVehicle);
	}
	@GetMapping("/details/{vehicleNo}")
	public List<UserVehicleEntity> getAllUserData(@PathVariable String vehicleNo){
			return vehicleDetails.getAllData(vehicleNo);
	}
	@PostMapping("/addTrip")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<Object> addTripForUser(@Valid @RequestBody TripDetails tripDetails){
		return addTripDetails.saveData(tripDetails);
	}
	@PostMapping("/test")
	@ResponseStatus(HttpStatus.CREATED)
	public String test(){
		return "OK";
	}
}

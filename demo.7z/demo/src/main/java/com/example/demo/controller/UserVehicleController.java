package com.example.demo.controller;

import com.example.demo.model.UserVehicleEntity;
import com.example.demo.model.Vehicle;
import com.example.demo.serviceImpl.VehicleDetailsDaoImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;


@RestController
@RequestMapping(path = "/userVehicle")
public class UserVehicleController {
	@Autowired
	VehicleDetailsDaoImpl vehicleDetails;

	@PostMapping("/signup")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<String> createUser(@Valid @RequestBody Vehicle newVehicle) {
		return vehicleDetails.saveData(newVehicle);
	}
	@PutMapping("/update")
	public ResponseEntity<String> updateUser(@Valid @RequestBody Vehicle newVehicle){
		return vehicleDetails.updateData(newVehicle);
	}
	@GetMapping("/details/{email}")
	public List<UserVehicleEntity> getAllUserData(@PathVariable String email){
			return vehicleDetails.getAllData(email);
	}
}
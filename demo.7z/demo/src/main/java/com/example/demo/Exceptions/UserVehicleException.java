package com.example.demo.Exceptions;

import com.example.demo.model.ApiError;

public class UserVehicleException extends RuntimeException{
    private static final long serialVersionUID = -8460356990632230194L;

    private final ApiError apiError;

    public UserVehicleException(ApiError apiError) {
        super();
        this.apiError = apiError;
    }
    public ApiError getApiError() {
        return apiError;
    }
}

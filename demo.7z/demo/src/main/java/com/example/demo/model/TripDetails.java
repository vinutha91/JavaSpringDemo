package com.example.demo.model;

import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotEmpty;
import java.util.Date;

public class TripDetails {

    public String uniqueId;

    @NotEmpty(message = "Please provide a vehicle no")
    public String vehicleNo;

    @NotEmpty(message = "Please provide your last trip reading.")
    @DecimalMin(value = "0.00",message = "Please provide a valid last trip numeric reading.")
    public String lastTripReading;

    @NotEmpty(message = "Please provide your current kms reading.")
    @DecimalMin(value = "0.00",message = "Please provide a valid current kms numeric reading.")
    public String currentKmsReading;

    @NotEmpty(message = "Please provide petrol filled for amount field.")
    @DecimalMin(value = "0.00",message = "Please provide a valid filled for amount reading.")
    public String petrolFilledForAmt;

    @NotEmpty(message = "Please provide fuel price per litre.")
    @DecimalMin(value = "0.00",message = "Please provide a valid fuel price per litre reading.")
    public String fuelPricePerltr;

    @NotEmpty(message = "Please specify litres filled.")
    @DecimalMin(value = "0.00",message = "Please provide a valid litres numeric reading.")
    public String litresFilled;

    /*@NotEmpty(message = "Please provide last updated date.")*/
    /*@DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date myDate;*/

    public String lastUpdatedDate;

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }


    public String getCurrentKmsReading() {
        return currentKmsReading;
    }

    public void setCurrentKmsReading(String currentKmsReading) {
        this.currentKmsReading = currentKmsReading;
    }

    public String getPetrolFilledForAmt() {
        return petrolFilledForAmt;
    }

    public void setPetrolFilledForAmt(String petrolFilledForAmt) {
        this.petrolFilledForAmt = petrolFilledForAmt;
    }

    public String getFuelPricePerltr() {
        return fuelPricePerltr;
    }

    public void setFuelPricePerltr(String fuelPricePerltr) {
        this.fuelPricePerltr = fuelPricePerltr;
    }

    public String getVehicleNo() {
        return vehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }

    public String getLastTripReading() {
        return lastTripReading;
    }

    public void setLastTripReading(String lastTripReading) {
        this.lastTripReading = lastTripReading;
    }

    public String getLitresFilled() {
        return litresFilled;
    }

    public void setLitresFilled(String litresFilled) {
        this.litresFilled = litresFilled;
    }

    public String getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(String lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
}

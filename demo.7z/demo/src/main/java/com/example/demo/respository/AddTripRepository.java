package com.example.demo.respository;

import com.example.demo.model.AddTripEntity;
import com.example.demo.model.UserVehicleEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddTripRepository extends JpaRepository<AddTripEntity, String> {

}

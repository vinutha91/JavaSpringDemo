package com.example.demo.serviceImpl;
import com.example.demo.Exceptions.UserServiceException;
import com.example.demo.Exceptions.UserVehicleException;
import com.example.demo.model.ApiError;
import com.example.demo.model.UserVehicleEntity;
import com.example.demo.model.Vehicle;
/*import com.example.demo.respository.UserVehicleDataRepository;*/
import com.example.demo.respository.UserVehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.transaction.Transactional;
import java.util.List;


@Service
public class VehicleDetailsDaoImpl{
	@Autowired
	UserVehicleRepository userVehicleRepo;

	// Any failure causes the entire operation to roll back, none of the book will be added
@Transactional
	public ResponseEntity<Object> saveData(Vehicle newVehicle) throws UserVehicleException {
		        /*UserVehicleEntity u=	userVehicleRepo.getOne("123");*/
	UserVehicleEntity values = new UserVehicleEntity();

				if(userVehicleRepo.existsById(newVehicle.vehicleNo)){
					throw new UserVehicleException(new ApiError("400",
							"User already exists"));
				}

				values.setVehicle_no(newVehicle.vehicleNo);
				values.setInitial_kms_reading(newVehicle.initialKmsReading);
				values.setUser_name(newVehicle.user_name);
				values.setVehicle_model(newVehicle.vehicleModel);
				values.setUser_email_address(newVehicle.userEmail);
				userVehicleRepo.save(values);
				//todo - add try catch in controller
				return new ResponseEntity<>("OK", HttpStatus.OK);


	}

	@Transactional
	public ResponseEntity<String> updateData(Vehicle newvehicle){
			return userVehicleRepo.findById(newvehicle.vehicleNo)
					.map(x -> {
						x.setInitial_kms_reading(newvehicle.initialKmsReading);
						x.setUser_email_address(newvehicle.userEmail);
						x.setUser_name(newvehicle.user_name);
						x.setVehicle_model(newvehicle.vehicleModel);
						 userVehicleRepo.save(x);
						return new ResponseEntity<>("OK", HttpStatus.OK);
					}).orElseThrow(() -> new RuntimeException("No Records found."));
		}

	public List<UserVehicleEntity> getAllData(String vehicleNo){
		return userVehicleRepo.findAllDataWithVehicleNo(vehicleNo);
	}
	/*public addTripDetails(String vehicleNo){

	}*/
}

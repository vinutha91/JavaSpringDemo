package com.example.demo.serviceImpl;
import com.example.demo.Exceptions.UserServiceException;
import com.example.demo.model.UserVehicleEntity;
import com.example.demo.model.Vehicle;
/*import com.example.demo.respository.UserVehicleDataRepository;*/
import com.example.demo.respository.UserVehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;


@Service
public class VehicleDetailsDaoImpl{
	@Autowired
	UserVehicleRepository userVehicleRepo;

	// Any failure causes the entire operation to roll back, none of the book will be added
@Transactional
	public ResponseEntity<String> saveData(Vehicle newVehicle) throws UserServiceException {
		        /*UserVehicleEntity u=	userVehicleRepo.getOne("123");*/

	            UserVehicleEntity values = new UserVehicleEntity();

					if(userVehicleRepo.existsById(newVehicle.vehicle_no)){
						throw new UserServiceException("User already exists");
					}

					values.setVehicle_no(newVehicle.vehicle_no);
					values.setInitial_kms_reading(newVehicle.initial_kms_reading);
					values.setUser_name(newVehicle.user_name);
					values.setVehicle_model(newVehicle.vehicle_model);
					values.setUser_email_address(newVehicle.user_email_address);
					userVehicleRepo.save(values);
					return new ResponseEntity<>("OK", HttpStatus.OK);
	}

	@Transactional
	public ResponseEntity<String> updateData(Vehicle newvehicle){
			return userVehicleRepo.findById(newvehicle.vehicle_no)
					.map(x -> {
						x.setInitial_kms_reading(newvehicle.initial_kms_reading);
						x.setUser_email_address(newvehicle.user_email_address);
						x.setUser_name(newvehicle.user_name);
						x.setVehicle_model(newvehicle.vehicle_model);
						 userVehicleRepo.save(x);
						return new ResponseEntity<>("OK", HttpStatus.OK);
					}).orElseThrow(() -> new RuntimeException("No Records found."));
		}

	public List<UserVehicleEntity> getAllData(String email){
		return userVehicleRepo.findAllDataWithEmail(email);
	}
}

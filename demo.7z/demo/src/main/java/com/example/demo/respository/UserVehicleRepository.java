package com.example.demo.respository;

import com.example.demo.model.UserVehicleEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

//<Entityname,data type of primary key>
public interface UserVehicleRepository extends JpaRepository<UserVehicleEntity, String> {

    @Query("SELECT j from UserVehicleEntity j where j.vehicle_no= :vehicleNo")
    List<UserVehicleEntity> findAllDataWithVehicleNo(String vehicleNo);
}

package com.example.demo.model;

import org.springframework.format.annotation.NumberFormat;

import javax.persistence.Column;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import com.example.demo.constants.Constants;

public class Vehicle {

    @NotEmpty(message = "Please provide a vehicle no")
    public String vehicle_no;

    @NotEmpty(message = "Please provide a name..")
    public String user_name;

    @NotNull(message = "Please provide a reading")
    @DecimalMin(value = "0.00",message = "Please provide a valid numeric reading.")

    public Float initial_kms_reading;

    @NotEmpty(message = "Please provide a vehicle model")
    public String vehicle_model;

     @Column(unique=true,nullable=false)
	 @Pattern(regexp = Constants.EMAIL_REGEX)

     public String user_email_address;

    public String getVehicle_no() {
        return vehicle_no;
    }
    public void setVehicle_no(String vehicle_no) {
        this.vehicle_no = vehicle_no;
    }
    public String getUser_name() {
        return user_name;
    }
    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }
    public Float getInitial_kms_reading() {
        return initial_kms_reading;
    }
    public void setInitial_kms_reading(Float initial_kms_reading) {
        this.initial_kms_reading = initial_kms_reading;
    }
    public String getVehicle_model() {
        return vehicle_model;
    }
    public void setVehicle_model(String vehicle_model) {
        this.vehicle_model = vehicle_model;
    }
    public String getUser_email_address() {
        return user_email_address;
    }
    public void setUser_email_address(String user_email_address) {
        this.user_email_address = user_email_address;
    }
}

package com.example.demo.model;

        import org.hibernate.annotations.GenericGenerator;

        import javax.persistence.*;
        import java.util.Date;

@Entity
public class AddTripEntity {

    @Id @GeneratedValue(generator="system-uuid")
    @GenericGenerator(name="system-uuid", strategy = "uuid")
    private String uniqueId;

    private String vehicleNo;

    private String lastTripReading;

    private String litresFilled;

    private String lastUpdatedDate;

    private String currentKmsReading;

    private String petrolFilledForAmt;

    private String fuelPricePerltr;

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }
    public String getCurrentKmsReading() {
        return currentKmsReading;
    }

    public void setCurrentKmsReading(String currentKmsReading) {
        this.currentKmsReading = currentKmsReading;
    }

    public String getPetrolFilledForAmt() {
        return petrolFilledForAmt;
    }

    public void setPetrolFilledForAmt(String petrolFilledForAmt) {
        this.petrolFilledForAmt = petrolFilledForAmt;
    }

    public String getFuelPricePerltr() {
        return fuelPricePerltr;
    }

    public void setFuelPricePerltr(String fuelPricePerltr) {
        this.fuelPricePerltr = fuelPricePerltr;
    }

    public String getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(String lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public String getLastTripReading() {
        return lastTripReading;
    }

    public void setLastTripReading(String lastTripReading) {
        this.lastTripReading = lastTripReading;
    }

    public String getLitresFilled() {
        return litresFilled;
    }

    public void setLitresFilled(String litresFilled) {
        this.litresFilled = litresFilled;
    }

    public String getVehicleNo() {
        return vehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }
}

package com.example.demo.model;

import org.hibernate.validator.constraints.Email;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.*;

@Entity
public class UserVehicleEntity {
	@Id
	/*@NotEmpty(message = "Please provide a vehicle no")*/
	private String vehicle_no;

	/*@NotEmpty(message = "Please provide a name..")*/
	private String user_name;

	/*@NotNull(message = "Please provide a reading")
	@DecimalMin("1.00")*/
	private float initial_kms_reading;

	/*@NotEmpty(message = "Please provide a vehicle name")*/
	private String vehicle_model;

	/*@Column(unique=true,nullable=false)*/
	/*@Pattern(regexp = "^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}$")*/
	private String user_email_address;
	
	
	public String getVehicle_no() {
		return vehicle_no;
	}
	public void setVehicle_no(String vehicle_no) {
		this.vehicle_no = vehicle_no;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public float getInitial_kms_reading() {
		return initial_kms_reading;
	}
	public void setInitial_kms_reading(float initial_kms_reading) {
		this.initial_kms_reading = initial_kms_reading;
	}
	public String getVehicle_model() {
		return vehicle_model;
	}
	public void setVehicle_model(String vehicle_model) {
		this.vehicle_model = vehicle_model;
	}
	public String getUser_email_address() {
		return user_email_address;
	}
	public void setUser_email_address(String user_email_address) {
		this.user_email_address = user_email_address;
	}
}

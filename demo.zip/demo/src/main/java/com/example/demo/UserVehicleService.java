package com.example.demo;

import org.springframework.stereotype.Service;


public interface UserVehicleService {
	 void insertEmployee(Vehicle veh);
}

package com.example.demo;

public interface UserVehicleDao {
	void insertUserVehicle(Vehicle veh);
}

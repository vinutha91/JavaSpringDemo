package com.example.demo;
import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class UserVehicleEntity {
	@Id
	private String vehicle_no;
	private String user_name;
	private int initial_kms_reading;
	private String vehicle_model;
	private String user_email_address;
	
	
	public String getVehicle_no() {
		return vehicle_no;
	}
	public void setVehicle_no(String vehicle_no) {
		this.vehicle_no = vehicle_no;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public int getInitial_kms_reading() {
		return initial_kms_reading;
	}
	public void setInitial_kms_reading(int initial_kms_reading) {
		this.initial_kms_reading = initial_kms_reading;
	}
	public String getVehicle_model() {
		return vehicle_model;
	}
	public void setVehicle_model(String vehicle_model) {
		this.vehicle_model = vehicle_model;
	}
	public String getUser_email_address() {
		return user_email_address;
	}
	public void setUser_email_address(String user_email_address) {
		this.user_email_address = user_email_address;
	}
}

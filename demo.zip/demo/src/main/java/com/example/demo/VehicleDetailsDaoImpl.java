package com.example.demo;
import com.example.demo.Exceptions.UserVehicleException;
import com.example.demo.model.ApiError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;


@Service

public class VehicleDetailsDaoImpl{
	@Autowired
	UserVehicleRepository userVehicleRepo;

@Transactional
	public ResponseEntity<String> saveData(Vehicle newVehicle) {
		        if(userVehicleRepo.existsById(newVehicle.vehicle_no)){
						throw new UserVehicleException(
								new ApiError("400",
										"User has already been registered.")
						);
				}
		        /*UserVehicleEntity u=	userVehicleRepo.getOne("123");*/

	UserVehicleEntity values = new UserVehicleEntity();
		        /*System.out.println(u.getUser_email_address());*/
					values.setVehicle_no(newVehicle.vehicle_no);
					values.setInitial_kms_reading(newVehicle.initial_kms_reading);
					values.setUser_name(newVehicle.user_name);
					values.setVehicle_model(newVehicle.vehicle_model);
					values.setUser_email_address(newVehicle.user_email_address);
					userVehicleRepo.save(values);
					return new ResponseEntity<>("sdf", HttpStatus.OK);

	}
}

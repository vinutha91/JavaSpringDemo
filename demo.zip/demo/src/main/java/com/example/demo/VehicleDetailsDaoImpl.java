package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;



@Service

public class VehicleDetailsDaoImpl{
	@Autowired
	UserVehicleRepository userVehicleRepo;
	UserVehicleEntity values = new UserVehicleEntity();
	public void saveData() {
		
		values.setVehicle_no("123");
		values.setInitial_kms_reading(1233);
		
		userVehicleRepo.save(values);
	}
	
}

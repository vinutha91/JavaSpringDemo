package com.example.demo;

import java.lang.reflect.Member;
import java.net.URI;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(path = "/userVehicle")
@ResponseBody
//@ResponseStatus(HttpStatus.OK)
public class UserVehicleController {
	@Autowired
	VehicleDetailsDaoImpl vehicleDetails;
	

/*	@GetMapping("/test")
	public ResponseEntity<String> createEmployee() {
		vehicleDetails.saveData();
		
		return new ResponseEntity<>("sdf",HttpStatus.OK);
		
	}*/
	@PostMapping("/signup")
	public ResponseEntity<String> createUser(@RequestBody Vehicle newVehicle) {
		try {
			vehicleDetails.saveData(newVehicle);
		}
		catch(DataIntegrityViolationException e) {
			System.out.println("User already exist");
		}
		return null;
	}
	/*
	 * @PostMapping(path="/userSignUp", consumes = "application/json") public void
	 * postInitialUserData(@RequestBody VehicleDetailsDaoImpl vehicleDetails) {
	 * vehicleDetails.saveData(); }
	 * 
	 * @PostMapping(path = "/members", consumes = "application/json", produces =
	 * "application/json") public void addMember(@RequestBody Member member) {
	 * //code }
	 */	
}


/*
 * @PostMapping(path="/userSignUp", consumes = "application/json") public void
 * postInitialUserData(@RequestBody VehicleDetailsDaoImpl vehicleDetails) {
 * vehicleDetails.saveData(); }
 * 
 * @PostMapping(path = "/members", consumes = "application/json", produces =
 * "application/json") public void addMember(@RequestBody Member member) {
 * //code }
 */	

package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

//<Entityname,data type of primary key>
public interface UserVehicleRepository extends JpaRepository<UserVehicleEntity, String> {
	
}

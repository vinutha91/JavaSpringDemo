package com.example.demo.Exceptions;

import com.example.demo.model.ApiError;

public class UserVehicleException extends RuntimeException{
    private final ApiError apiError;

    public UserVehicleException(ApiError apiError) {
        super();
        this.apiError = apiError;
    }
}
